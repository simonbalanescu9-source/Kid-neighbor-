# Neighborhood Quest

A GitHub-ready browser game where you play as a kid exploring a neighborhood full of activities.

## Features

- Walkable open neighborhood
- Complex procedural-looking textures made with Canvas and CSS
- Houses, gardens, roads, park, pond, market, skate park, basketball court
- Activities:
  - Deliver newspapers
  - Water garden patches
  - Clean park litter
  - Fish at the pond
  - Shoot hoops
  - Practice skate tricks
  - Buy snacks
  - Rest inside houses
  - Talk to NPCs
- Quests, coins, energy, reputation, and time system

## How to run

Open `index.html` in your browser.

## How to publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `game.js`, and this `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from branch**.
5. Select the `main` branch and root folder.
6. Open the GitHub Pages link after it deploys.

## Controls

- `WASD` / arrow keys: move
- `Shift`: run
- `E`: interact
