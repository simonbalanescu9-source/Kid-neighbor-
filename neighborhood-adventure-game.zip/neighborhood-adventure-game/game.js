const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const TILE = 32;
const W = canvas.width;
const H = canvas.height;

const keys = new Set();
const state = {
  coins: 12,
  energy: 100,
  rep: 0,
  minute: 8 * 60,
  toastTimer: 0,
  inventory: { newspaper: 0, apples: 0, fish: 0, trash: 0 },
  quests: [
    { id: "paper", text: "Deliver 3 newspapers", target: 3, progress: 0, reward: 20, done: false },
    { id: "garden", text: "Water 4 garden patches", target: 4, progress: 0, reward: 15, done: false },
    { id: "trash", text: "Clean 5 pieces of park litter", target: 5, progress: 0, reward: 18, done: false },
    { id: "fish", text: "Catch 2 pond fish", target: 2, progress: 0, reward: 25, done: false }
  ]
};

const player = { x: 120, y: 120, w: 21, h: 25, speed: 2.25, dir: "down", step: 0 };

const colliders = [];
const interactables = [];
const particles = [];
const npcs = [];

function rect(x,y,w,h){ return {x,y,w,h}; }
function intersects(a,b){ return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y; }
function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }

function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  state.toastTimer = 170;
}

function addLog(msg) {
  const log = document.getElementById("activityLog");
  const div = document.createElement("div");
  div.className = "logItem";
  div.textContent = msg;
  log.prepend(div);
}

function addParticle(x, y, text) {
  particles.push({x,y,text,life:70,vy:-0.45});
}

function progressQuest(id, amount=1) {
  const q = state.quests.find(q => q.id === id);
  if (!q || q.done) return;
  q.progress += amount;
  if (q.progress >= q.target) {
    q.done = true;
    state.coins += q.reward;
    state.rep += 5;
    toast(`Quest complete: ${q.text}! +${q.reward} coins`);
    addLog(`Finished quest: ${q.text}`);
  }
}

function buildWorld() {
  // Houses
  addHouse(72, 65, "Miller House", "#9b5de5");
  addHouse(300, 70, "Blue Roof House", "#00bbf9");
  addHouse(690, 78, "Grandma's House", "#f15bb5");
  addHouse(83, 390, "Corner House", "#fee440");
  addHouse(682, 395, "Brick House", "#f97316");

  // Activity zones
  addZone(420, 385, 155, 105, "Skate Park", "skate", "Press E to practice tricks (-12 energy, +rep, chance coins)");
  addZone(410, 95, 170, 95, "Mini Market", "market", "Press E to buy a snack for 5 coins (+20 energy)");
  addZone(220, 410, 140, 120, "Community Garden", "garden", "Press E to water vegetables (-6 energy)");
  addZone(745, 235, 125, 105, "Pond", "fish", "Press E to fish (-8 energy)");
  addZone(520, 245, 92, 80, "Basketball Court", "basket", "Press E to shoot hoops (-10 energy, +rep)");

  // Newspaper pickup
  interactables.push({
    ...rect(35, 210, 70, 55),
    name: "Newspaper Box",
    type: "paperbox",
    prompt: "Press E to grab 3 newspapers",
    action() {
      state.inventory.newspaper += 3;
      toast("You picked up 3 newspapers.");
      addLog("Picked up newspapers for delivery.");
    }
  });

  // Park litter
  for (let i = 0; i < 8; i++) {
    const x = 450 + Math.random()*190, y = 505 + Math.random()*70;
    interactables.push({
      ...rect(x,y,18,18),
      name: "Park Litter",
      type: "trash",
      prompt: "Press E to clean litter (+1 coin, +rep)",
      cleaned: false,
      action(obj) {
        if (obj.cleaned) return toast("Already cleaned.");
        obj.cleaned = true;
        state.coins += 1;
        state.rep += 1;
        progressQuest("trash");
        addParticle(obj.x, obj.y, "+clean");
        addLog("Cleaned litter in the park.");
      }
    });
  }

  // Delivery mailboxes
  for (const p of [[125,175],[353,177],[742,186],[138,500],[740,500]]) {
    interactables.push({
      ...rect(p[0],p[1],22,28),
      name: "Mailbox",
      type: "mailbox",
      prompt: "Press E to deliver newspaper",
      delivered: false,
      action(obj) {
        if (obj.delivered) return toast("This house already got a newspaper.");
        if (state.inventory.newspaper <= 0) return toast("Grab newspapers from the newspaper box first.");
        state.inventory.newspaper--;
        obj.delivered = true;
        state.coins += 3;
        state.rep += 1;
        progressQuest("paper");
        addParticle(obj.x, obj.y, "+3");
        addLog("Delivered a newspaper.");
      }
    });
  }

  npcs.push({x:640,y:285,w:22,h:28,name:"Mia",line:"Mia: I heard the pond has rare sparkle fish today!"});
  npcs.push({x:245,y:235,w:22,h:28,name:"Leo",line:"Leo: The skate park gives more reputation if your energy is high."});
  npcs.push({x:590,y:470,w:22,h:28,name:"Nora",line:"Nora: Cleaning the park makes everyone respect you."});
}

function addHouse(x, y, name, roof) {
  colliders.push(rect(x,y,120,92));
  interactables.push({
    ...rect(x+38,y+70,44,28),
    name,
    type: "door",
    prompt: "Press E to rest inside (+35 energy, time passes)",
    action() {
      state.energy = clamp(state.energy + 35, 0, 100);
      state.minute += 25;
      toast(`You rested at ${name}. Energy restored.`);
      addLog(`Rested at ${name}.`);
    }
  });
}

function addZone(x,y,w,h,name,type,prompt) {
  interactables.push({
    ...rect(x,y,w,h),
    name, type, prompt,
    cooldown: 0,
    action(obj) {
      if (obj.cooldown > 0) return toast("Try again in a moment.");
      if (type === "market") {
        if (state.coins < 5) return toast("Not enough coins for a snack.");
        state.coins -= 5;
        state.energy = clamp(state.energy + 20,0,100);
        state.minute += 8;
        addLog("Bought a snack at the mini market.");
        toast("Snack eaten. +20 energy.");
      }
      if (type === "garden") {
        if (!spendEnergy(6)) return;
        progressQuest("garden");
        state.rep += 1;
        state.minute += 10;
        addParticle(player.x, player.y, "🌱");
        addLog("Watered the community garden.");
        toast("You watered a garden patch.");
      }
      if (type === "fish") {
        if (!spendEnergy(8)) return;
        state.minute += 15;
        const caught = Math.random() > 0.35;
        if (caught) {
          state.inventory.fish++;
          state.coins += 4;
          progressQuest("fish");
          addParticle(player.x, player.y, "🐟 +4");
          addLog("Caught a fish at the pond.");
          toast("You caught a fish! +4 coins.");
        } else toast("The fish escaped!");
      }
      if (type === "basket") {
        if (!spendEnergy(10)) return;
        state.minute += 12;
        const made = Math.random() > 0.45;
        state.rep += made ? 2 : 1;
        if (made) state.coins += 2;
        addParticle(player.x, player.y, made ? "swish +2" : "almost");
        addLog(made ? "Scored at basketball." : "Practiced basketball.");
        toast(made ? "Swish! +2 coins, +rep." : "Almost! +rep.");
      }
      if (type === "skate") {
        if (!spendEnergy(12)) return;
        state.minute += 14;
        const style = Math.random();
        const gain = state.energy > 45 && style > 0.28 ? 4 : 2;
        state.rep += gain;
        if (style > 0.55) state.coins += 3;
        addParticle(player.x, player.y, style > 0.55 ? "kickflip +3" : "trick!");
        addLog("Practiced skate tricks.");
        toast(`Skate trick landed! +${gain} rep.`);
      }
      obj.cooldown = 28;
    }
  });
}

function spendEnergy(n) {
  if (state.energy < n) {
    toast("Too tired. Rest at a house or buy a snack.");
    return false;
  }
  state.energy -= n;
  return true;
}

function drawGrass() {
  const g = ctx.createLinearGradient(0,0,0,H);
  g.addColorStop(0, "#85c96b");
  g.addColorStop(1, "#65a95a");
  ctx.fillStyle = g;
  ctx.fillRect(0,0,W,H);

  // Complex grass texture
  for (let y=0; y<H; y+=8) {
    for (let x=0; x<W; x+=8) {
      const n = Math.sin(x*0.045) + Math.cos(y*0.061) + Math.sin((x+y)*0.027);
      ctx.fillStyle = n > .9 ? "rgba(255,255,255,.08)" : n < -.9 ? "rgba(0,0,0,.08)" : "rgba(20,80,20,.04)";
      ctx.fillRect(x,y,8,8);
      if ((x*y + y) % 104 === 0) {
        ctx.strokeStyle = "rgba(28,90,34,.28)";
        ctx.beginPath();
        ctx.moveTo(x+3,y+8);
        ctx.lineTo(x+5,y+2);
        ctx.stroke();
      }
    }
  }
}

function drawRoads() {
  // asphalt with lane texture
  ctx.fillStyle = "#3b4652";
  ctx.fillRect(0, 300, W, 70);
  ctx.fillRect(610, 0, 70, H);
  ctx.fillStyle = "rgba(255,255,255,.06)";
  for (let x=0; x<W; x+=16) for (let y=300; y<370; y+=16) ctx.fillRect(x,y,4,2);
  for (let y=0; y<H; y+=16) for (let x=610; x<680; x+=16) ctx.fillRect(x,y,4,2);
  ctx.strokeStyle = "#f7e98e";
  ctx.setLineDash([22,18]);
  ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(0,335); ctx.lineTo(W,335); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(645,0); ctx.lineTo(645,H); ctx.stroke();
  ctx.setLineDash([]);
  ctx.lineWidth = 1;
  ctx.strokeStyle = "rgba(0,0,0,.25)";
  ctx.strokeRect(0,300,W,70);
  ctx.strokeRect(610,0,70,H);
}

function drawHouse(x,y,roofColor,label) {
  // shadow
  ctx.fillStyle = "rgba(0,0,0,.22)";
  ctx.fillRect(x+8,y+12,120,92);

  // siding texture
  const wall = ctx.createLinearGradient(x,y,x+120,y+92);
  wall.addColorStop(0, "#f5e7c8");
  wall.addColorStop(1, "#d7bd8f");
  ctx.fillStyle = wall;
  ctx.fillRect(x,y+32,120,60);

  for (let i=0;i<8;i++) {
    ctx.strokeStyle = i%2 ? "rgba(255,255,255,.25)" : "rgba(90,54,25,.22)";
    ctx.beginPath();
    ctx.moveTo(x, y+36+i*7);
    ctx.lineTo(x+120, y+36+i*7);
    ctx.stroke();
  }

  ctx.fillStyle = roofColor;
  ctx.beginPath();
  ctx.moveTo(x-10,y+36);
  ctx.lineTo(x+60,y-14);
  ctx.lineTo(x+130,y+36);
  ctx.closePath();
  ctx.fill();

  // roof shingles
  ctx.strokeStyle = "rgba(0,0,0,.25)";
  for (let i=0;i<6;i++) {
    ctx.beginPath();
    ctx.moveTo(x+8+i*18,y+24-i%2*3);
    ctx.lineTo(x+58+i*4,y-5+i*5);
    ctx.stroke();
  }

  // windows
  for (const wx of [x+15,x+80]) {
    ctx.fillStyle = "#a7d8ff";
    ctx.fillRect(wx,y+45,25,22);
    ctx.strokeStyle = "#335";
    ctx.strokeRect(wx,y+45,25,22);
    ctx.beginPath();
    ctx.moveTo(wx+12,y+45); ctx.lineTo(wx+12,y+67);
    ctx.moveTo(wx,y+56); ctx.lineTo(wx+25,y+56);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,.45)";
    ctx.fillRect(wx+3,y+48,7,4);
  }

  ctx.fillStyle = "#7c3f18";
  ctx.fillRect(x+49,y+60,24,32);
  ctx.fillStyle = "#facc15";
  ctx.beginPath(); ctx.arc(x+68,y+76,2,0,Math.PI*2); ctx.fill();

  ctx.fillStyle = "rgba(17,24,39,.8)";
  ctx.font = "11px system-ui";
  ctx.fillText(label, x+5, y+106);
}

function drawWorldObjects() {
  drawHouse(72,65,"#9b5de5","Miller");
  drawHouse(300,70,"#00bbf9","Blue Roof");
  drawHouse(690,78,"#f15bb5","Grandma");
  drawHouse(83,390,"#fee440","Corner");
  drawHouse(682,395,"#f97316","Brick");

  // market
  ctx.fillStyle = "#e11d48";
  ctx.fillRect(410,95,170,95);
  ctx.fillStyle = "#f8fafc";
  for (let x=414; x<580; x+=22) ctx.fillRect(x,95,12,18);
  ctx.fillStyle = "#fed7aa";
  ctx.fillRect(425,125,140,55);
  ctx.fillStyle = "#111827";
  ctx.font = "bold 18px system-ui";
  ctx.fillText("MINI MARKET", 435, 156);

  // garden rows
  ctx.fillStyle = "#7c4a24";
  ctx.fillRect(220,410,140,120);
  for (let y=422; y<525; y+=24) {
    ctx.fillStyle = "#4d7c0f";
    ctx.fillRect(232,y,116,10);
    for (let x=236; x<345; x+=16) {
      ctx.fillStyle = "#86efac";
      ctx.beginPath();
      ctx.arc(x,y+5,5,0,Math.PI*2);
      ctx.fill();
    }
  }

  // skate park
  ctx.fillStyle = "#9ca3af";
  ctx.fillRect(420,385,155,105);
  ctx.fillStyle = "#6b7280";
  ctx.beginPath(); ctx.moveTo(435,470); ctx.quadraticCurveTo(470,420,505,470); ctx.fill();
  ctx.beginPath(); ctx.moveTo(505,470); ctx.quadraticCurveTo(540,420,560,470); ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.25)";
  for (let i=0;i<40;i+=8){ctx.beginPath();ctx.moveTo(420,385+i);ctx.lineTo(575,385+i+15);ctx.stroke();}

  // court
  ctx.fillStyle = "#d97706";
  ctx.fillRect(520,245,92,80);
  ctx.strokeStyle = "#fff7ed";
  ctx.strokeRect(528,253,76,64);
  ctx.beginPath(); ctx.arc(566,285,18,0,Math.PI*2); ctx.stroke();
  ctx.fillStyle = "#111827"; ctx.fillRect(602,272,5,28);
  ctx.fillStyle = "#f97316"; ctx.beginPath(); ctx.arc(585,288,7,0,Math.PI*2); ctx.fill();

  // pond
  const pond = ctx.createRadialGradient(807,288,12,807,288,85);
  pond.addColorStop(0,"#7dd3fc");
  pond.addColorStop(1,"#0369a1");
  ctx.fillStyle = pond;
  ctx.beginPath(); ctx.ellipse(807,288,72,55,0,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.4)";
  for(let i=0;i<4;i++){ctx.beginPath();ctx.ellipse(807,288,20+i*12,10+i*8,0,0,Math.PI*2);ctx.stroke();}

  // park trees
  for (let i=0; i<12; i++) drawTree(395+i*44, 528 + (i%3)*18);

  // newspaper box
  ctx.fillStyle = "#2563eb"; ctx.fillRect(35,210,70,55);
  ctx.fillStyle = "#eff6ff"; ctx.fillRect(45,220,50,18);
  ctx.fillStyle = "#111827"; ctx.font = "10px system-ui"; ctx.fillText("NEWS", 56,233);

  // mailboxes
  for (const p of [[125,175],[353,177],[742,186],[138,500],[740,500]]) drawMailbox(p[0],p[1]);
}

function drawTree(x,y) {
  ctx.fillStyle = "#7c2d12"; ctx.fillRect(x+13,y+20,10,25);
  const grad = ctx.createRadialGradient(x+18,y+20,4,x+18,y+20,28);
  grad.addColorStop(0,"#86efac");
  grad.addColorStop(1,"#166534");
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(x+18,y+18,24,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,.18)";
  ctx.beginPath(); ctx.arc(x+8,y+8,7,0,Math.PI*2); ctx.fill();
}

function drawMailbox(x,y) {
  ctx.fillStyle = "#374151"; ctx.fillRect(x+9,y+17,4,22);
  ctx.fillStyle = "#dc2626"; ctx.fillRect(x,y,22,18);
  ctx.fillStyle = "#fecaca"; ctx.fillRect(x+3,y+3,12,5);
}

function drawInteractables() {
  for (const o of interactables) {
    if (o.type === "trash" && !o.cleaned) {
      ctx.fillStyle = "#e5e7eb";
      ctx.save();
      ctx.translate(o.x+9,o.y+9);
      ctx.rotate((o.x+o.y)%3);
      ctx.fillRect(-7,-5,14,10);
      ctx.restore();
    }
    if (o.cooldown > 0) o.cooldown--;
  }
}

function drawNpcs() {
  for (const n of npcs) {
    ctx.fillStyle = "#111827";
    ctx.fillRect(n.x+4,n.y+13,14,17);
    ctx.fillStyle = "#fcd34d";
    ctx.beginPath(); ctx.arc(n.x+11,n.y+8,9,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = "#38bdf8";
    ctx.fillRect(n.x+2,n.y+21,18,12);
    ctx.fillStyle = "#111827";
    ctx.font = "10px system-ui";
    ctx.fillText(n.name, n.x-2, n.y-6);
  }
}

function drawPlayer() {
  player.step += 0.08;
  ctx.save();
  ctx.translate(player.x, player.y);
  ctx.fillStyle = "rgba(0,0,0,.25)";
  ctx.beginPath(); ctx.ellipse(11,25,14,5,0,0,Math.PI*2); ctx.fill();

  // backpack
  ctx.fillStyle = "#7c3aed";
  ctx.fillRect(-1,9,7,15);

  // body hoodie with texture
  ctx.fillStyle = "#22c55e";
  ctx.fillRect(4,10,16,16);
  ctx.strokeStyle = "rgba(255,255,255,.25)";
  ctx.beginPath(); ctx.moveTo(5,14); ctx.lineTo(19,14); ctx.moveTo(12,10); ctx.lineTo(12,26); ctx.stroke();

  // face / hair
  ctx.fillStyle = "#f9c98b";
  ctx.beginPath(); ctx.arc(12,6,9,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = "#3f2418";
  ctx.beginPath(); ctx.arc(9,1,8,Math.PI,Math.PI*2); ctx.fill();

  // legs animated
  const s = Math.sin(player.step) * 3;
  ctx.fillStyle = "#1d4ed8";
  ctx.fillRect(5,25,5,12+s/3);
  ctx.fillRect(15,25,5,12-s/3);
  ctx.fillStyle = "#111827";
  ctx.fillRect(3,36+s/3,8,4);
  ctx.fillRect(13,36-s/3,8,4);

  ctx.restore();
}

function drawParticles() {
  ctx.font = "bold 14px system-ui";
  for (let i=particles.length-1; i>=0; i--) {
    const p = particles[i];
    p.life--; p.y += p.vy;
    ctx.globalAlpha = p.life / 70;
    ctx.fillStyle = "#fff7ed";
    ctx.fillText(p.text, p.x, p.y);
    ctx.globalAlpha = 1;
    if (p.life <= 0) particles.splice(i,1);
  }
}

function movePlayer() {
  let dx = 0, dy = 0;
  if (keys.has("arrowleft") || keys.has("a")) dx--;
  if (keys.has("arrowright") || keys.has("d")) dx++;
  if (keys.has("arrowup") || keys.has("w")) dy--;
  if (keys.has("arrowdown") || keys.has("s")) dy++;
  if (dx && dy) { dx *= 0.707; dy *= 0.707; }
  const speed = keys.has("shift") && state.energy > 0 ? player.speed * 1.55 : player.speed;
  if (keys.has("shift") && (dx || dy)) state.energy = clamp(state.energy - 0.035, 0, 100);

  const nextX = {...player, x: clamp(player.x + dx*speed, 0, W-player.w)};
  if (!colliders.some(c => intersects(nextX,c))) player.x = nextX.x;

  const nextY = {...player, y: clamp(player.y + dy*speed, 0, H-player.h)};
  if (!colliders.some(c => intersects(nextY,c))) player.y = nextY.y;

  if (dx || dy) state.minute += 0.01;
}

function nearestThing() {
  const p = rect(player.x-12, player.y-12, player.w+24, player.h+24);
  let best = null;
  for (const o of interactables) {
    if (intersects(p,o) && !(o.type==="trash" && o.cleaned)) best = o;
  }
  for (const n of npcs) if (intersects(p,n)) best = n;
  return best;
}

function interact() {
  const obj = nearestThing();
  if (!obj) return toast("Nothing to interact with here.");
  if (obj.line) {
    toast(obj.line);
    addLog(`Talked to ${obj.name}.`);
    return;
  }
  obj.action(obj);
}

function updateUI() {
  document.getElementById("coins").textContent = Math.floor(state.coins);
  document.getElementById("energy").textContent = Math.floor(state.energy);
  document.getElementById("rep").textContent = Math.floor(state.rep);
  const h = Math.floor(state.minute / 60) % 24;
  const m = Math.floor(state.minute % 60);
  document.getElementById("clock").textContent = `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;

  const near = nearestThing();
  document.getElementById("nearby").textContent = near ? (near.prompt || near.line) : "Walk around the neighborhood.";

  document.getElementById("quests").innerHTML = state.quests.map(q =>
    `<li class="${q.done ? "done" : ""}">${q.text}: ${Math.min(q.progress,q.target)}/${q.target}</li>`
  ).join("");
}

function drawDayTint() {
  const h = Math.floor(state.minute/60)%24;
  let alpha = 0;
  if (h < 6 || h >= 20) alpha = 0.38;
  else if (h >= 18) alpha = 0.15;
  if (alpha) {
    ctx.fillStyle = `rgba(15,23,42,${alpha})`;
    ctx.fillRect(0,0,W,H);
  }
}

function loop() {
  movePlayer();
  drawGrass();
  drawRoads();
  drawWorldObjects();
  drawInteractables();
  drawNpcs();
  drawPlayer();
  drawParticles();
  drawDayTint();
  updateUI();

  if (state.toastTimer > 0) {
    state.toastTimer--;
    if (state.toastTimer === 0) document.getElementById("toast").classList.remove("show");
  }

  requestAnimationFrame(loop);
}

window.addEventListener("keydown", e => {
  keys.add(e.key.toLowerCase());
  if (e.key.toLowerCase() === "e") interact();
});
window.addEventListener("keyup", e => keys.delete(e.key.toLowerCase()));

document.getElementById("helpBtn").onclick = () => {
  document.getElementById("modal").classList.remove("hidden");
  document.getElementById("modalBody").innerHTML = `
    <p><kbd>WASD</kbd> or <kbd>Arrow Keys</kbd> move around.</p>
    <p><kbd>Shift</kbd> runs but drains energy.</p>
    <p><kbd>E</kbd> interacts with houses, activities, NPCs, mailboxes, and litter.</p>
    <p>Activities include fishing, basketball, skateboarding, gardening, newspaper delivery, shopping, resting, and park cleanup.</p>
  `;
};

document.getElementById("closeModal").onclick = () => document.getElementById("modal").classList.add("hidden");

buildWorld();
addLog("Welcome to Neighborhood Quest!");
toast("Explore the neighborhood. Press E near things.");
loop();
